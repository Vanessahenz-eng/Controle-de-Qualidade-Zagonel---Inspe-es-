# Controle de Inspeções — Zagonel

App de controle de inspeções diárias dos setores Apoio B2-03, B1-01 e Injeção.

## Deploy no Render

1. Crie um repositório no GitHub chamado `zagonel-inspecoes`
2. Suba estes arquivos para o repositório
3. Crie um novo Web Service no Render conectando ao repositório
4. Configure as variáveis de ambiente:
   - `UPLOAD_KEY` = senha para importar dados (ex: Zagonel@2025)
   - `GITHUB_TOKEN` = token do GitHub para backup
   - `GITHUB_REPO` = usuario/zagonel-inspecoes
